-- ═══════════════════════════════════════════════════════════════
-- NFC IET Portal — Sample Seed Data for Production Use
-- Run this AFTER running the schema SQL
-- ═══════════════════════════════════════════════════════════════

USE nfc_portal;

-- ═══════════════════════════════════════════════════════════════
-- 1. DEPARTMENTS
-- ═══════════════════════════════════════════════════════════════
INSERT INTO departments (name, code) VALUES
('Computer Science', 'CS'),
('Electrical Engineering', 'EE'),
('Mechanical Engineering', 'ME'),
('Civil Engineering', 'CE'),
('Business Administration', 'BBA'),
('Mathematics & Physics', 'MP');

-- ═══════════════════════════════════════════════════════════════
-- 2. PROGRAMS
-- ═══════════════════════════════════════════════════════════════
INSERT INTO programs (name, dept_id, duration_years, total_semesters) VALUES
('BS Computer Science', 1, 4, 8),
('BS Software Engineering', 1, 4, 8),
('BS Data Science', 1, 4, 8),
('BS Electrical Engineering', 2, 4, 8),
('BS Mechanical Engineering', 3, 4, 8),
('BS Civil Engineering', 4, 4, 8),
('BBA (Hons)', 5, 4, 8),
('BS Mathematics', 6, 4, 8);

-- ═══════════════════════════════════════════════════════════════
-- 3. COURSES
-- ═══════════════════════════════════════════════════════════════
INSERT INTO courses (code, name, dept_id, credit_hours, total_marks, mid_weight, final_weight, assign_weight) VALUES
-- Computer Science
('CS-101', 'Introduction to Programming', 1, 3, 100, 30, 50, 20),
('CS-102', 'Object Oriented Programming', 1, 3, 100, 30, 50, 20),
('CS-201', 'Data Structures & Algorithms', 1, 3, 100, 30, 50, 20),
('CS-202', 'Database Systems', 1, 3, 100, 30, 50, 20),
('CS-301', 'Operating Systems', 1, 3, 100, 30, 50, 20),
('CS-302', 'Computer Networks', 1, 3, 100, 30, 50, 20),
('CS-401', 'Artificial Intelligence', 1, 3, 100, 30, 50, 20),
('CS-402', 'Software Engineering', 1, 3, 100, 30, 50, 20),
('CS-LAB1', 'Programming Lab I', 1, 1, 100, 40, 40, 20),
('CS-LAB2', 'Programming Lab II', 1, 1, 100, 40, 40, 20),

-- Electrical Engineering
('EE-101', 'Circuit Analysis I', 2, 3, 100, 30, 50, 20),
('EE-102', 'Electronics I', 2, 3, 100, 30, 50, 20),
('EE-201', 'Digital Logic Design', 2, 3, 100, 30, 50, 20),
('EE-202', 'Signals & Systems', 2, 3, 100, 30, 50, 20),
('EE-301', 'Power Systems', 2, 3, 100, 30, 50, 20),
('EE-302', 'Control Systems', 2, 3, 100, 30, 50, 20),

-- Mechanical Engineering
('ME-101', 'Engineering Mechanics', 3, 3, 100, 30, 50, 20),
('ME-102', 'Thermodynamics', 3, 3, 100, 30, 50, 20),
('ME-201', 'Fluid Mechanics', 3, 3, 100, 30, 50, 20),
('ME-202', 'Machine Design', 3, 3, 100, 30, 50, 20),

-- General/University
('ENG-101', 'English Composition', 6, 3, 100, 30, 50, 20),
('MATH-101', 'Calculus I', 6, 3, 100, 30, 50, 20),
('MATH-102', 'Calculus II', 6, 3, 100, 30, 50, 20),
('MATH-201', 'Linear Algebra', 6, 3, 100, 30, 50, 20),
('MATH-202', 'Probability & Statistics', 6, 3, 100, 30, 50, 20),
('ISL-101', 'Islamic Studies', 6, 2, 100, 30, 50, 20),
('PKS-101', 'Pakistan Studies', 6, 2, 100, 30, 50, 20);

-- ═══════════════════════════════════════════════════════════════
-- 4. ADMIN USER
-- ═══════════════════════════════════════════════════════════════
INSERT INTO users (email, password_hash, role) VALUES
('admin@nfc.edu', 'admin123', 'admin');

-- ═══════════════════════════════════════════════════════════════
-- 5. TEACHERS (with users)
-- ═══════════════════════════════════════════════════════════════
INSERT INTO users (email, password_hash, role) VALUES
('ali.ahmed@nfc.edu', 'teacher123', 'teacher'),
('fatima.khan@nfc.edu', 'teacher123', 'teacher'),
('usman.malik@nfc.edu', 'teacher123', 'teacher'),
('sara.raza@nfc.edu', 'teacher123', 'teacher'),
('imran.qureshi@nfc.edu', 'teacher123', 'teacher'),
('nadia.hassan@nfc.edu', 'teacher123', 'teacher'),
('tariq.jamal@nfc.edu', 'teacher123', 'teacher'),
('amna.siddiqui@nfc.edu', 'teacher123', 'teacher');

INSERT INTO teachers (user_id, name, dept_id, designation, phone, qualification, specialization, joining_date) VALUES
(2, 'Dr. Ali Ahmed', 1, 'Professor', '0300-1234567', 'PhD CS (MIT)', 'Machine Learning', '2018-08-15'),
(3, 'Dr. Fatima Khan', 1, 'Associate Professor', '0301-2345678', 'PhD SE (Stanford)', 'Software Architecture', '2019-01-10'),
(4, 'Usman Malik', 2, 'Assistant Professor', '0302-3456789', 'MS EE (NUST)', 'Power Electronics', '2020-03-20'),
(5, 'Sara Raza', 3, 'Lecturer', '0303-4567890', 'MS ME (UET)', 'Thermal Systems', '2021-06-01'),
(6, 'Imran Qureshi', 1, 'Lecturer', '0304-5678901', 'MS CS (FAST)', 'Web Development', '2021-09-15'),
(7, 'Dr. Nadia Hassan', 6, 'Professor', '0305-6789012', 'PhD Mathematics (Oxford)', 'Applied Mathematics', '2017-02-01'),
(8, 'Tariq Jamal', 5, 'Assistant Professor', '0306-7890123', 'MBA (LUMS)', 'Finance', '2019-11-20'),
(9, 'Amna Siddiqui', 1, 'Lecturer', '0307-8901234', 'MS DS (NUST)', 'Data Analytics', '2022-01-10');

-- ═══════════════════════════════════════════════════════════════
-- 6. STUDENTS (with users) — Sample batch 2022
-- ═══════════════════════════════════════════════════════════════
INSERT INTO users (email, password_hash, role) VALUES
('2022cs001@nfc.edu', 'student123', 'student'),
('2022cs002@nfc.edu', 'student123', 'student'),
('2022cs003@nfc.edu', 'student123', 'student'),
('2022cs004@nfc.edu', 'student123', 'student'),
('2022cs005@nfc.edu', 'student123', 'student'),
('2022ee001@nfc.edu', 'student123', 'student'),
('2022ee002@nfc.edu', 'student123', 'student'),
('2022me001@nfc.edu', 'student123', 'student'),
('2022bba001@nfc.edu', 'student123', 'student'),
('2022bba002@nfc.edu', 'student123', 'student');

INSERT INTO students (user_id, name, roll_no, program_id, batch, semester, phone, gender, address, cnic, guardian_name, guardian_phone, admission_date, status) VALUES
(10, 'Ahmed Hassan', '2022-CS-001', 1, '2022', 6, '0311-1111111', 'male', 'House 12, Street 5, Multan', '35201-1234567-1', 'Hassan Ali', '0300-1111111', '2022-09-01', 'active'),
(11, 'Bilal Khan', '2022-CS-002', 1, '2022', 6, '0312-2222222', 'male', 'House 34, Gulgasht Colony, Multan', '35201-2345678-2', 'Khan Muhammad', '0300-2222222', '2022-09-01', 'active'),
(12, 'Ayesha Siddiqui', '2022-CS-003', 2, '2022', 6, '0313-3333333', 'female', 'Flat 5, Officers Colony, Multan', '35201-3456789-3', 'Siddiqui Ahmad', '0300-3333333', '2022-09-01', 'active'),
(13, 'Zara Malik', '2022-CS-004', 1, '2022', 6, '0314-4444444', 'female', 'House 78, Shah Rukn-e-Alam Road, Multan', '35201-4567890-4', 'Malik Tariq', '0300-4444444', '2022-09-01', 'active'),
(14, 'Usman Ghani', '2022-CS-005', 3, '2022', 6, '0315-5555555', 'male', 'House 90, Northern Bypass, Multan', '35201-5678901-5', 'Ghani Rehman', '0300-5555555', '2022-09-01', 'active'),
(15, 'Hamza Tariq', '2022-EE-001', 4, '2022', 6, '0316-6666666', 'male', 'House 45, Bosan Road, Multan', '35201-6789012-6', 'Tariq Mehmood', '0300-6666666', '2022-09-01', 'active'),
(16, 'Sanaullah Khan', '2022-EE-002', 4, '2022', 6, '0317-7777777', 'male', 'House 67, Vehari Road, Multan', '35201-7890123-7', 'Khan Jamshed', '0300-7777777', '2022-09-01', 'active'),
(17, 'Rashid Amin', '2022-ME-001', 5, '2022', 6, '0318-8888888', 'male', 'House 23, Khanewal Road, Multan', '35201-8901234-8', 'Aminullah', '0300-8888888', '2022-09-01', 'active'),
(18, 'Fatima Zahra', '2022-BBA-001', 7, '2022', 6, '0319-9999999', 'female', 'House 56, Model Town, Multan', '35201-9012345-9', 'Zahra Ali', '0300-9999999', '2022-09-01', 'active'),
(19, 'Omar Farooq', '2022-BBA-002', 7, '2022', 6, '0320-0000000', 'male', 'House 89, Jalalpur Pirwala Road, Multan', '35201-0123456-0', 'Farooq Ahmad', '0300-0000000', '2022-09-01', 'active');

-- ═══════════════════════════════════════════════════════════════
-- 7. SECTIONS (Spring 2025)
-- ═══════════════════════════════════════════════════════════════
INSERT INTO sections (course_id, teacher_id, section_label, semester, year, room) VALUES
-- CS 6th Semester
(1, 2, 'A', 'Spring', 2025, 'Lab-101'),
(2, 3, 'A', 'Spring', 2025, 'Lab-102'),
(5, 2, 'A', 'Spring', 2025, 'Room-201'),
(6, 6, 'A', 'Spring', 2025, 'Lab-103'),
(7, 2, 'A', 'Spring', 2025, 'Room-202'),
(8, 3, 'A', 'Spring', 2025, 'Room-203'),
(21, 7, 'A', 'Spring', 2025, 'Room-301'),
(22, 7, 'A', 'Spring', 2025, 'Room-302'),

-- EE 6th Semester
(11, 4, 'A', 'Spring', 2025, 'Lab-201'),
(12, 4, 'A', 'Spring', 2025, 'Lab-202'),
(15, 4, 'A', 'Spring', 2025, 'Room-401'),

-- ME 6th Semester
(17, 5, 'A', 'Spring', 2025, 'Workshop-A'),
(18, 5, 'A', 'Spring', 2025, 'Workshop-B'),

-- BBA 6th Semester
(24, 8, 'A', 'Spring', 2025, 'Room-501'),
(25, 8, 'A', 'Spring', 2025, 'Room-502');

-- ═══════════════════════════════════════════════════════════════
-- 8. ENROLLMENTS
-- ═══════════════════════════════════════════════════════════════
INSERT INTO enrollments (student_id, section_id) VALUES
-- Ahmed Hassan (CS-001)
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8),
-- Bilal Khan (CS-002)
(2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8),
-- Ayesha Siddiqui (SE-003)
(3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 6), (3, 7), (3, 8),
-- Zara Malik (CS-004)
(4, 1), (4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (4, 7), (4, 8),
-- Usman Ghani (DS-005)
(5, 1), (5, 2), (5, 3), (5, 4), (5, 5), (5, 6), (5, 7), (5, 8),
-- Hamza Tariq (EE-001)
(6, 9), (6, 10), (6, 11), (6, 7), (6, 8),
-- Sanaullah Khan (EE-002)
(7, 9), (7, 10), (7, 11), (7, 7), (7, 8),
-- Rashid Amin (ME-001)
(8, 12), (8, 13), (8, 7), (8, 8),
-- Fatima Zahra (BBA-001)
(9, 14), (9, 15), (9, 7), (9, 8),
-- Omar Farooq (BBA-002)
(10, 14), (10, 15), (10, 7), (10, 8);

-- ═══════════════════════════════════════════════════════════════
-- 9. GRADES (sample data)
-- ═══════════════════════════════════════════════════════════════
INSERT INTO grades (enrollment_id, mid_marks, final_marks, assignment_marks) VALUES
-- Ahmed Hassan
(1, 25.5, 42.0, 18.0),   -- CS-101
(2, 24.0, 40.5, 17.5),   -- CS-102
(3, 26.0, 43.0, 18.5),   -- CS-301
(4, 23.5, 38.0, 16.0),   -- CS-302
(5, 27.0, 44.0, 19.0),   -- CS-401
(6, 22.0, 36.5, 15.5),   -- CS-402
(7, 28.0, 45.0, 19.5),   -- MATH-201
(8, 25.0, 41.0, 17.0),   -- MATH-202

-- Bilal Khan
(9, 20.0, 35.0, 15.0),
(10, 22.5, 37.5, 16.5),
(11, 24.0, 39.0, 17.0),
(12, 21.0, 34.0, 14.5),
(13, 23.5, 38.5, 16.0),
(14, 20.5, 33.0, 14.0),
(15, 26.0, 42.0, 18.0),
(16, 24.5, 40.0, 17.0),

-- Ayesha Siddiqui
(17, 28.5, 46.0, 19.5),
(18, 27.0, 44.5, 19.0),
(19, 29.0, 47.0, 20.0),
(20, 26.5, 43.0, 18.5),
(21, 28.0, 45.5, 19.5),
(22, 25.0, 41.0, 17.5),
(23, 27.5, 44.0, 18.5),
(24, 26.0, 42.5, 18.0),

-- Zara Malik
(25, 15.0, 28.0, 12.0),
(26, 18.0, 32.0, 14.0),
(27, 20.0, 35.0, 15.5),
(28, 17.5, 30.0, 13.5),
(29, 19.0, 33.0, 14.5),
(30, 16.0, 29.0, 13.0),
(31, 22.0, 38.0, 16.0),
(32, 20.5, 36.0, 15.5),

-- Usman Ghani
(33, 24.0, 40.0, 17.0),
(34, 25.5, 41.5, 17.5),
(35, 23.0, 38.5, 16.5),
(36, 22.0, 37.0, 16.0),
(37, 24.5, 40.5, 17.5),
(38, 21.0, 35.0, 15.0),
(39, 26.0, 43.0, 18.5),
(40, 25.0, 41.0, 17.5);

-- ═══════════════════════════════════════════════════════════════
-- 10. ATTENDANCE (sample - last 30 days)
-- ═══════════════════════════════════════════════════════════════
-- We'll generate attendance for enrollment_id 1 (Ahmed Hassan - CS-101) as sample
INSERT INTO attendance (enrollment_id, date, status) VALUES
(1, '2025-04-01', 'present'),
(1, '2025-04-03', 'present'),
(1, '2025-04-05', 'present'),
(1, '2025-04-08', 'late'),
(1, '2025-04-10', 'present'),
(1, '2025-04-12', 'present'),
(1, '2025-04-15', 'absent'),
(1, '2025-04-17', 'present'),
(1, '2025-04-19', 'present'),
(1, '2025-04-22', 'present'),
(1, '2025-04-24', 'present'),
(1, '2025-04-26', 'late'),
(1, '2025-04-29', 'present');

-- ═══════════════════════════════════════════════════════════════
-- 11. TIMETABLE
-- ═══════════════════════════════════════════════════════════════
INSERT INTO timetable (section_id, day, start_time, end_time, room) VALUES
-- CS-101 Section A (Dr. Ali Ahmed)
(1, 'Monday',    '09:00:00', '11:00:00', 'Lab-101'),
(1, 'Wednesday', '09:00:00', '11:00:00', 'Lab-101'),
(1, 'Friday',    '11:00:00', '13:00:00', 'Lab-101'),

-- CS-102 Section A (Dr. Fatima Khan)
(2, 'Monday',    '11:00:00', '13:00:00', 'Lab-102'),
(2, 'Wednesday', '11:00:00', '13:00:00', 'Lab-102'),
(2, 'Friday',    '09:00:00', '11:00:00', 'Lab-102'),

-- CS-301 Section A (Dr. Ali Ahmed)
(3, 'Tuesday',   '09:00:00', '11:00:00', 'Room-201'),
(3, 'Thursday',  '09:00:00', '11:00:00', 'Room-201'),

-- CS-302 Section A (Imran Qureshi)
(4, 'Tuesday',   '11:00:00', '13:00:00', 'Lab-103'),
(4, 'Thursday',  '11:00:00', '13:00:00', 'Lab-103'),

-- MATH-201 Section A (Dr. Nadia Hassan)
(7, 'Monday',    '14:00:00', '16:00:00', 'Room-301'),
(7, 'Wednesday', '14:00:00', '16:00:00', 'Room-301'),

-- MATH-202 Section A (Dr. Nadia Hassan)
(8, 'Tuesday',   '14:00:00', '16:00:00', 'Room-302'),
(8, 'Thursday',  '14:00:00', '16:00:00', 'Room-302');

-- ═══════════════════════════════════════════════════════════════
-- 12. FEE RECORDS
-- ═══════════════════════════════════════════════════════════════
INSERT INTO fee_records (student_id, semester, year, amount, due_date, status, paid_at) VALUES
-- Ahmed Hassan
(1, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-10'),
(1, 'Spring', 2025, 85000, '2025-02-15', 'paid', '2025-02-08'),

-- Bilal Khan
(2, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-12'),
(2, 'Spring', 2025, 85000, '2025-02-15', 'overdue', NULL),

-- Ayesha Siddiqui
(3, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-08'),
(3, 'Spring', 2025, 85000, '2025-02-15', 'paid', '2025-02-05'),

-- Zara Malik
(4, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-14'),
(4, 'Spring', 2025, 85000, '2025-02-15', 'pending', NULL),

-- Usman Ghani
(5, 'Fall', 2024, 95000, '2024-09-15', 'paid', '2024-09-11'),
(5, 'Spring', 2025, 95000, '2025-02-15', 'paid', '2025-02-10'),

-- Hamza Tariq
(6, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-09'),
(6, 'Spring', 2025, 85000, '2025-02-15', 'pending', NULL),

-- Sanaullah Khan
(7, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-13'),
(7, 'Spring', 2025, 85000, '2025-02-15', 'paid', '2025-02-12'),

-- Rashid Amin
(8, 'Fall', 2024, 85000, '2024-09-15', 'paid', '2024-09-07'),
(8, 'Spring', 2025, 85000, '2025-02-15', 'overdue', NULL),

-- Fatima Zahra
(9, 'Fall', 2024, 75000, '2024-09-15', 'paid', '2024-09-06'),
(9, 'Spring', 2025, 75000, '2025-02-15', 'paid', '2025-02-03'),

-- Omar Farooq
(10, 'Fall', 2024, 75000, '2024-09-15', 'paid', '2024-09-11'),
(10, 'Spring', 2025, 75000, '2025-02-15', 'pending', NULL);

-- ═══════════════════════════════════════════════════════════════
-- 13. ANNOUNCEMENTS
-- ═══════════════════════════════════════════════════════════════
INSERT INTO announcements (teacher_id, section_id, title, body) VALUES
(2, 1, 'Mid-Term Exam Schedule', 'Mid-term exams will be held from May 15-20, 2025. Please check the timetable and prepare accordingly.'),
(2, 1, 'Assignment 3 Deadline Extended', 'The deadline for Assignment 3 has been extended to May 10, 2025.'),
(3, 2, 'Lab Report Guidelines', 'All lab reports must follow the IEEE format. Templates are available on the course portal.'),
(6, 4, 'Project Groups Formation', 'Please form groups of 3-4 students for the final project by May 5, 2025.'),
(7, 7, 'Quiz on April 30', 'There will be a surprise quiz on Linear Transformations on April 30. Be prepared!');

-- ═══════════════════════════════════════════════════════════════
-- 14. NOTIFICATIONS
-- ═══════════════════════════════════════════════════════════════
INSERT INTO notifications (user_id, type, title, message) VALUES
(10, 'info', 'Welcome to Spring 2025', 'Your classes for Spring 2025 semester have started. Check your timetable.'),
(10, 'warning', 'Fee Due', 'Your Spring 2025 fee is due by February 15, 2025.'),
(10, 'success', 'Fee Paid', 'Your fee payment of Rs. 85,000 has been received.'),
(11, 'info', 'Welcome to Spring 2025', 'Your classes for Spring 2025 semester have started. Check your timetable.'),
(11, 'error', 'Fee Overdue', 'Your Spring 2025 fee is overdue. Please pay immediately to avoid penalties.'),
(12, 'info', 'Welcome to Spring 2025', 'Your classes for Spring 2025 semester have started. Check your timetable.'),
(12, 'success', 'Fee Paid', 'Your fee payment of Rs. 85,000 has been received.');
